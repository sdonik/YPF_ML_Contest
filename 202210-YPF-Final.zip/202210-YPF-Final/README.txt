Pasos para ejecutar el script:

1- Subir al drive en la carpeta root el folder '202210-YPF' contenido en este zip
2- Abrir la notebook en google colab y correr la misma, en una primer montara drive (pedirá permisos) e instalará las libs necesarias en su versión correspondiente
3- Restartear el runtime para tomar los cambios y correr la notebook entera


Esto descargara en la carpeta 202210-YPF/submissions la solución final, que se corresponde con la enviada originalmente, para que no se pise se generara con el nombre submit_V30.csv
